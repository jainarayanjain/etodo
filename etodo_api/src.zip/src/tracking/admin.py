from django.contrib import admin
from tracking.models import Task

admin.site.register(Task)
