from celery import shared_task
from django.utils import timezone

from tracking.models import Task
from tracking.helpers import through_email


@shared_task()
def email_task() -> None:
    """Email Task"""
    date = timezone.now().isoformat().split("T")[0]
    start = f"{date}T00:00:00.0Z"
    end = f"{date}T23:59:59.0Z"
    list_of_task = list(
        Task.objects.filter(
            created__gte=start, created__lte=end, is_closed=False
        ).values("name")
    )
    if len(list_of_task) != 0:
        subject = "Reminder"
        body = "Xyz"
        to = "jainarayanjain8171@gmail.com"
        through_email(subject, body, to)
