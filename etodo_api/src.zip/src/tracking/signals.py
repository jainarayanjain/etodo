from django.dispatch import Signal

tracking_signal = Signal()
