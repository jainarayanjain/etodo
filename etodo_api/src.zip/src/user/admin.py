from django.contrib import admin
from user.models import Profile

admin.site.register(Profile)
